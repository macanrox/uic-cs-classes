Bresia Prudente
679176497, bprude2@uic.edu
CS 480 - Database Systems

Included in the submission are files contained in folders "pt1" and "pt2".

The ER-Diagrams are drawn using https://www.draw.io/ and are displayed in HTML format
as I was unable to save them with image extensions.

