#include <stdio.h>

/* Bresia Prudente, bprude2
   Siham Hussein, shusse6
 */

int main (int argc, const char * argv[]) 
{
	int i=0; 
	while(i<25){ 
		printf("Welcome to CS 261\n");
		i++;
	}

}
