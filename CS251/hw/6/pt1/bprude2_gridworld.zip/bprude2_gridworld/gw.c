#include "gw.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//* DECLARE STRUCTS *//

/*
struct gw_struct:
	This creates a struct based on the size of the
	world, the districts, population, and members.
*/
struct gwStruct{
	int nrows;
	int ncols;
	int popSizeTotal;
	int memberSize;

	struct structDistrict **members;
	struct dummyDistrict ***world;
	struct stackStruct *emptyID;
};

/*
struct structDistrict
	We specify the district sizes, their identification, and
	notable variable names for traversing the district arrays.
*/
struct structDistrict{
	int row;
	int col;
	int ID;

	struct structDistrict *next;
	struct dummyDistrict *prev;
};

/*
struct dummyDistrict
	We create a dummy struct so that we can pinpoint
	the population size of the district. This is interpreted
	as the head of the district stack.
*/
struct dummyDistrict{
	int popSizeDistrict;

	struct districtStruct *head;
};

/*
struct stackStruct
	This struct takes the member IDs and traverses through
	the array.
*/
struct stackStruct{
	int ID;

	struct stackStruct *next;
};

/* GLOBAL STRUCT VARIABLES */
typedef struct structDistrict *districtPtr;
typedef struct dummyDistrict *dumDistrictPtr;
typedef struct stackStruct *stackPtr;

/*
dumDistrictPtr** structAlloc(int gwRows, int gwCols)
	This starts off the world and district as NULL
	and 0 respectively. Since we have to do this, we
	allocate space for the pointers to struct
*/
dumDistrictPtr** structAlloc(int nrows, int ncols)
{

	int x, y;
	dumDistrictPtr** world = malloc(nrows * sizeof(dumDistrictPtr));

	for(x=0; x<nrows; x++)				//for loop gives row size
	{
		world[x] = malloc(ncols * sizeof(dumDistrictPtr));
		for(y=0; y<ncols; y++)			//for loop gives column size
		{
			world[x][y] = malloc(sizeof(struct dummyDistrict));		//allocate space for struct to pointer
			(world[x][y])->popSizeDistrict = 0;						//set struct->popSizeDistrict to 0
			(world[x][y])->head = NULL;								//set struct->head to NULL
		}//end for(y=0...
	}//end for(x=0...

	return world;

}//end dumDistrictPtr**...


/*
void pushToDistrict(gw ptr, int rows, int cols, int ID)
	This function creates a new node for the district.
	It continuously updates both the population in the district
	and the total world population.
*/
void pushToDistrict(GW gwPtr, int row, int col, int ID)
{

	/* This will create the new district node and add information */
	gwPtr->members[ID] = malloc(sizeof(struct structDistrict));
	districtPtr temp = gwPtr->members[ID];
	temp->row = row;
	temp->col = col;
	temp->ID = ID;

	/* This checks if there are any empty districts.
	   If there are any, then point the head to the new node
	 */
	if(gwPtr->(world[row][col])->head == NULL)
	{
		temp->next = gwPtr->(world[row][col])->head;
		temp->prev = NULL;
		gwPtr->(world[row][col])->head = temp;
	}//end if

	/* Otherwise add the new node into the district stack
	   and increment the district population
	 */
	else
	{
		temp->next = gwPtr->(world[row][col])->head;
		temp->prev = NULL;
		gwPtr->(world[row][col])->head->prev = temp;
		gwPtr->(world[row][col])->head = temp;
	}//end else

	gwPtr->(world[row][col])->popSizeDistrict += 1;	//increment the district population
	gwPtr->popSizeTotal += 1;	//update the total population

}//end void pushToDistrict

/*
void pushID(gw gwPtr, int ID)
	This sends a new ID to an unused ID stack
 */
void pushID(GW gwPtr, int ID)
{

	stackPtr temp = malloc(sizeof(struct stackStruct));
	temp->ID = ID;
	temp->next = gwPtr->emptyID;
	gwPtr->emptyID = temp;

	return;

}//end pushID

/*
int popID(GW gwPtr)
	Pops the top most ID from the ID stack
 */
int popID(GW gwPtr)
{
	/* If the stack is empty, then return an error */
	if(gwPtr->emptyID == NULL)
	{
		return(-1);
	}//end if

	/* Otherwise proceed to pop the ID */
	stackPtr temp = gwPtr->emptyID;
	gwPtr->emptyID = temp->next;
	int ID = temp->ID;
	free(temp);

	return ID;

}//end popID

/*
void printDistID(GW gwPtr, int rows, int cols)
	This will print the IDs of the specific district/s
 */
void printDistID(GW gwPtr, int row, int col)
{
	/* If the rows and columns are greater than the pointer values,
	   then return nothing.
	 */
	if((row >= (gwPtr->nrows)) || (col >= (gwPtr->ncols)))
	{
		return;
	}//end if

	districtPtr head = gwPtr->(world[row][col])->head;

	/* If the district is NULL, then print empty district*/
	if(head == NULL)
	{
		printf("District [%d,%d] has population of 0\n", row, col);
		return;
	}//end if

	/* Otherwise print the district and the IDs */
	printf("District [%d, %d] has population of %d\n", row, col, gwPtr->(world[row][col])->popSizeDistrict);
	while(head != NULL)
	{
		printf("ID: %d\n", head->ID);
		head = head->next;
	}//end while
}//end void printDistID

/*
void freeEmptyID(stackPtr ptr)
	This frees the unused ID stack
 */
void freeEmptyID(stackPtr ptr)
{
	if(ptr == NULL)
	{
		return;
	}//end if

	freeEmptyID(ptr->next);	//recursively free the stack

}//end freeEmptyID

/*
void freeDistrict(districtPtr ptr)
	This frees the district
 */
void freeDistrict(districtPtr ptr)
{
	if(ptr == NULL)
	{
		return;
	}//end if
	else
	{
		freeDistrict(ptr->next);
	}//end else
}//end void freeDistrict


//*****REQUIRED FUNCTIONS******//

/*
GW gw_build(int nrows, int ncols, int pop, int rnd)
	Initializes the gridworld accordingly to the
	specifications of the given parameters.
*/
GW gw_build(int nrows, int ncols, int pop, int rnd)
{
	/* Allocate the world array and then set the emptyID as NULL */
	GW gwPtr = malloc(sizeof(struct gwStruct));
	gwPtr->world = structAlloc(nrows, ncols);
	gwPtr->emptyID = NULL;

	/* This array represents the members or people */
	gwPtr->members = malloc(pop * sizeof(districtPtr));
	gwPtr->memberSize = pop;
	gwPtr->nrows = nrows;
	gwPtr->ncols = ncols;

	/* Then we add values into the people array */
	int row, col = 0;
	int x;
	for(x=0; x<pop; x++)
	{
		/* If user chooses random, then the rows and columns are randomly set */
		if(rnd)
		{
			row = rand() % nrows;
			col = rand() % ncols;
			pushToDistrict(gwPtr, row, col, x);
		}//end if
		/* Otherwise set the rows and columns to a set value */
		else
		{
			pushToDistrict(gwPtr, 0, 0, x);
		}//end else
	}//end for

	return gwPtr;

}//end GW gw_build...

/*
int * gw_members(GW gwPtr, int row, int col, int *n)
	This returns an integer array that contains the members of a district [i,j].
	It also stores in *n the number of entries in the array (Nij)
 */
int * gw_members(GW gwPtr, int row, int col, int *n)
{
	/* If (i, j) is invalid, NULL is returned */
	if((row >= (gwPtr->nrows)) || (col >= (gwPtr->ncols))
	{
		return NULL;
	}//end if

	*n = gwPtr->(world[row][col])->popSizeDistrict;

	int *arr = malloc((*n) * sizeof(int));
	districtPtr head = gwPtr(world[row][col])->head;

	int x;

	/* Traverse through the array */
	for(x=0; x<(*n); x++)
	{
		arr[x] = head->ID;
		head = head->next;
	}//end for

	/* Otherwise return the array */
	return arr;

}//end int * gw_members

/*
int gw_district_pop(GW gwPtr, int row, int col)
	This displays the number of living in district [i,j]
		Example: > population 2 7
				   6
 */
int gw_district_pop(GW gwPtr, int row, int col)
{
	/* If no such district exists, return with an error */
	if((row >= (gwPtr->nrows)) || (col >= (gwPtr->ncols))
	{
		return(-1);
	}//end if
	/* Otherwise return the district and population */
	else
	{
		return gwPtr->(world[row][col])->popSizeDistrict;
	}//end else

}//end int gw_district_pop

/*
int gw_total_pop(GW gwPtr)
	This displays the total number of living people in the world
		Example: > population
				   10
 */
int gw_total_pop(GW gwPtr)
{

	return gwPtr->popSizeTotal;

}//end int gw_total_pop

/*
int gw_move(GW gwPtr, int ID, int i, int j)
	This moves the person x (if alive) from current district
	into a new district
		Example: > move 5 2 9
 */
int gw_move(GW gwPtr, int ID, int i, int j)
{

	/* If the ID doesn't exist in the district, return false */
	if(ID >= (gwPtr->memberSize))
	{
		return 0;
	}//end if

	/* If the ID doesn't match any of the district members, return false */
	if((gwPtr->members[ID]) == NULL)
	{
		return 0;
	}//end if

	/* If the district doesn't exist, return false */
	if((i > (gwPtr->nrows)) || (j > (gwPtr->ncols))
	{
		return 0;
	}//end if

	gw_kill(gwPtr, ID);
	popStack(gwPtr);
	pushToDistrict(gwPtr, i, j, ID);

	return 1;

}//end int gw_move

/*
int gw_find(GW gwPtr, int ID, int *row, int *col)
	If person x is alive and is within the district, then
	find the specific *row and *col of district
		Example: > find 8
*/
int gw_find(GW gwPtr, int ID, int *row, int *col)
{
	/* If the ID doesn't exist, then return false */
	if(gwPtr->members[ID] == NULL)
	{
		return 0;
	}//end if

	/* Otherwise display the district in which the member resides in */
	*row = gwPtr->members[ID]->row;
	*col = gwPtr->members[ID]->col;

	return 1;
}//end int gw_find

/*
int gw_kill(GW gwPtr, int ID)
	If person x is alive, remove from the district and world.
	Also update the district + world population size.
		Example: > kill 5
*/
int gw_kill(GW gwPtr, int ID)
{
	/* If the ID doesn't exist in the district, return false */
	if(ID >= (gwPtr->memberSize))
	{
		return 0;
	}//end if

	/* If the ID doesn't exist, return false */
	if(gwPtr->members[ID] == NULL)
	{
		return 0;
	}//end if

	/* We need to find the unique member ID*/
	int row, col;
	gw_find(gwPtr, ID, &row, &col);

	//If we find the ID, we have to figure out where it resides
	//in the stack.
	/* If the ID is the only node in the stack */
	if(((gwPtr->members[ID]->prev) == NULL) &&
	   ((gwPtr->members[ID]->next) == NULL))
	   {
		   gwPtr->(world[row][col])->head = NULL;
	   }//end if
	/* Or if the node is not alone and resides in the front */
	else if(((gwPtr->members[ID]->prev) == NULL) &&
	   	   ((gwPtr->members[ID]->next) != NULL))
	   {
	   		gwPtr->(world[row][col])->head = gwPtr->members[ID]->next;
	   		gwPtr->members[ID]->next->prev = NULL;
	   }//end if
	/* Or if the node is not alone and resides as the last node in the stack */
	else if(((gwPtr->members[ID]->prev) != NULL) &&
	   	   ((gwPtr->members[ID]->next) == NULL))
	   {
	   		gwPtr->members[ID]->prev->next = NULL;
	   }//end if
	/* Or if the node is surrounded by other nodes */
	else if(((gwPtr->members[ID]->prev) != NULL) &&
	   	   ((gwPtr->members[ID]->next) != NULL))
	   {
	   		gwPtr->members[ID]->prev->next = gwPtr->members[ID]->next;
	   		gwPtr->members[ID]->next->prev = gwPtr->members[ID]->prev;
	   }//end if

	/* Then free the ID memory and set the ID to NULL */
	free(gwPtr->member[ID]);
	gwPtr->members[ID] = NULL;

	/* We set aside the ID by pushing it into the unused ID stack */
	pushStack(gwPtr, ID);

	/* Then we update our district and world population */
	gwPtr->(world[row][col]->popSizeDistrict -= 1;		//decrement the size
	gwPtr->popSizeTotal -= 1;

	return 1;	//after this is done, return true

}//end int gw_kill

/*
int gw_create(GW gwPtr, int row, int col)
	Create a new person, assigns a unique ID, and places in
	district [i,j].
	The user is informed of the person's ID.
*/
int gw_create(GW gwPtr, int row, int col)
{

	/* If the input falls outside of parameters, then return an error */
	if((row > (gwPtr->nrows)) || (col > (gwPtr->ncols))
	{
		return (-1);
	}//end if

	int ID = popStack(gwPtr);

	if(ID == -1)
	{

		/* If the ID is a negative integer, then add 1 */
		ID = (gwPtr->memberSize) + 1;

		/* Increase the memberSize array */
		districtPtr *temp = malloc((gwPtr->memberSize+1) * sizeof(districtPtr));

		/* Copy the memory into the district */
		memcpy(temp, gwPtr->members, gwPtr->memberSize * sizeof(districtPtr));

		/* Update the number of members*/
		gwPtr->memberSize += 1;		//incrementing the memberSize
		free(gwPtr->members);
		gwPtr->members = temp;

		/* We make the last element equal to the ID */
		ID = gwPtr->memberSize - 1;

	}//end if

	pushToDistrict(gwPtr, row, col, ID);
	return ID;

}//end int gw_create

/*
void gw_free(GW gwPtr)
	This quits the program
*/
void gw_free(GW gwPtr)
{

	/* First free the ID stack */
	freeEmptyID(gwPtr->emptyID);

	/* Then free the world */
	int x, y;
	for(x=0; x<(gwPtr->nrows); x++)
	{
		for(y=0; y<(gwPtr->ncols);y++)
		{

			freeDistrict(gwPtr->(world[x][y])->head);	//free district
			free(gwPtr->world[x][y]);	//free dummy district

		}//end for(y=0...

		free(gwPtr->world[x]);	//free columns

	}//end for(x=0...

	free(gwPtr->world);		//free rows
	free(gwPtr->members);	//free members array
	free(gwPtr);			//free GW struct

	exit(1);	//exit program

}//end void gw_free