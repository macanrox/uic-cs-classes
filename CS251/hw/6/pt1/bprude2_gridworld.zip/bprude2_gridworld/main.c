#include "gw.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[])
{

	/*** Declare the rand() ***/
	srand(time(NULL));

	/*** Declare variables and initialize variables ***/
	int nPeople;
	int i, j, r, c, x, nrows, ncols, n;
	int *members = NULL;
	char userInput[50] = {0};	//we assume that the user can input a max of 50
	char rnd;
	GW gridworld = NULL:

	/*** User prompt ***/

	printf("Enter the following amounts for your gridworld.");

	//Ask for the rows
	printf("Number of rows: ");
	scanf("%d", &nrows);

	//Ask for the columns
	printf("Number of columns: ");
	scanf("%d", &ncols);

	//Ask for the number of people
	printf("Number of people: ");
	scanf("%d", &nPeople);

	//Ask if the user would like a random sized world
	printf("Random? (enter 'y' or 'n'): ");
	scanf("%c", &rnd);

	/*** Build the gridworld based on the random user choice ***/
	if(rnd == 'y')
	{
		gridworld = gw_build(nrows, ncols, nPeople, 1);
	}//end if
	else
	{
		gridworld = gw_build(nrows, ncols, nPeople, 0);
	}//end else

	/*** The program will continuously allow user inputs ***/
	while(1)
	{
		/* Get user input */
		printf("\nEnter a command: "
			   "\nEntering 'members' will display member information."
			   "\nEntering 'district' will display district information."
			   "\nEntering 'population' will display world information."
			   "\nEntering 'move' will transfer a person to a new district."
			   "\nEntering 'find' will initiate a search for the person."
			   "\nEntering 'kill' will erase a person from the district and world."
			   "\nEntering 'create' will allow you to add people."
			   "\nEntering 'quit' will delete your world and quit the program.")
		get_input(userInput);

		/* Call functions accordingly */
		if(strncmp(userInput, "members", 7) == 0)
		{
			sscanf(userInput + 7, "%d %d", &i, &j);
			members = gw_members(gridlworld, i, j, &n);
			printArray(members, n);
		}//end if
		else if(strncmp(userInput, "district", 8) == 0)
		{
			sscanf(userInput + 8, "%d %d", &i, &j);
			printf("%d\n", gw_disrict_pop(gridworld, i, j));
		}//end else if
		else if(strncmp(userInput, "population", 10) == 0)
		{
			printf("%d\n", gw_district_pop(gridworld));
		}//end else if
		else if(strncmp(userInput, "move", 4) == 0)
		{
			sscanf(userInput + 4, "%d %d %d", &x, &i, &j);
			gw_move(gridworld, x, i, j);
		}//end else if
		else if(strncmp(userInput, "find", 4) == 0)
		{
			sscanf(userInput + 4, "%d", &x);
			if(gw_find(gridworld, x, &r, &c))
			{
				printf("Member ID: %d is in district [%d, %d]\n", x, r, c);
			}//end if
		}//end else if
		else if(strncmp(userInput, "kill", 4) == 0)
		{
			sscanf(userInput + 4, "%d", &x);
			gw_kill(gridworld, x);
		}//end else if
		else if(strncmp(userInput, "create", 6) == 0)
		{
			sscanf(userInput + 6, "%d %d", &i, &j);
			gw_create(gridworld, i, j);
		}//end else if
		else if(strncmp(userInput, "quit", 4) == 0)
		{
			gw_free(gridworld);
			exit(1);
		}//end else if
		else
		{
			printf("Invalid command, please try again.\n");
		}//end else
		if(members != NULL)
		{
			free(members);
			members = NULL;
		}//end if
	}//end while
	return 0;

}//end main