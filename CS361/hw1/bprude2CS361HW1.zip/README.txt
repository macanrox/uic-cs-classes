CS 361: HW #1
Author: Bresia Prudente (bprude2)

======
README
======
The purpose of the assignment is to examine the process that converts the source code into an executable binary.

Included in the .zip file are:
mainC.c
func2C.c
README
makefile
CS361_Questionnaire.pdf
361_output_mainC_exec.txt
361_output_mainC_obj.txt
361_output_func2C_obj.txt

Running the makefile will create several files for mainC.c and func2C.c, including executable mainC.

mainC prints out the ACCC name, the value of "hello" and "world" from main, func1C, func2C, and func3C. It will also print out the result of func1C and func2C. 

============
INSTRUCTIONS
============

$ make

$ ./mainC
